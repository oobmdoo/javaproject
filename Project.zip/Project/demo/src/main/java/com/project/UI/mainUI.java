package com.project.UI;

import com.project.method.FoodSearchEngine;
import com.project.method.ReadExcel;
import com.project.method.UserProfile;
import com.project.method.DataManager;

import javax.swing.*;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.*;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

public class mainUI extends JFrame {
    // 핵심 컴포넌트
    private FoodSearchEngine searchEngine;
    private DataManager dataManager;
    private String currentProfileName;
    private JTextField searchField;
    private JTextField gramField;
    private JList<FoodSearchEngine.SearchResult> suggestionList;
    private DefaultListModel<FoodSearchEngine.SearchResult> listModel;
    private JTextArea nutritionArea;
    private JButton addButton;
    private JList<SelectedFood> selectedFoodsList;
    private DefaultListModel<SelectedFood> selectedFoodsModel;

    // 날짜 및 데이터 관리
    private LocalDate currentDate;
    private static Map<LocalDate, DailyNutritionData> dailyDataMap = new HashMap<>();
    private JLabel currentDateLabel;
    private CalendarUI calendarUI;

    // 영양 관리
    private NutritionGoals goals;
    private NutritionProgress progress;
    private JPanel progressPanel;

    // 사용자 프로필
    private UserProfile userProfile;
    private JButton profileButton;
    private JButton weeklyUpdateButton;

    // Jackson 호환 내부 클래스들
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class DailyNutritionData {
        @JsonProperty("foods")
        public List<SelectedFood> foods;

        @JsonProperty("progress")
        public NutritionProgress progress;

        public DailyNutritionData() {
            this.foods = new ArrayList<>();
            this.progress = new NutritionProgress();
        }

        public DailyNutritionData(List<SelectedFood> foods, NutritionProgress progress) {
            this.foods = new ArrayList<>();
            if (foods != null) {
                for (SelectedFood food : foods) {
                    this.foods.add(new SelectedFood(food.foodName, food.grams,
                            food.nutritionData != null ? new ArrayList<>(food.nutritionData) : new ArrayList<>()));
                }
            }
            this.progress = new NutritionProgress();
            if (progress != null) {
                this.progress.calories = progress.calories;
                this.progress.protein = progress.protein;
                this.progress.fat = progress.fat;
                this.progress.carbs = progress.carbs;
                this.progress.sugar = progress.sugar;
            }
        }
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class NutritionGoals {
        @JsonProperty("calories")
        public double calories = 2000;

        @JsonProperty("protein")
        public double protein = 50;

        @JsonProperty("fat")
        public double fat = 65;

        @JsonProperty("carbs")
        public double carbs = 300;

        @JsonProperty("sugar")
        public double sugar = 50;

        public NutritionGoals() {
        }

        public NutritionGoals(double calories, double protein, double fat, double carbs, double sugar) {
            this.calories = calories;
            this.protein = protein;
            this.fat = fat;
            this.carbs = carbs;
            this.sugar = sugar;
        }
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class NutritionProgress {
        @JsonProperty("calories")
        public double calories = 0;

        @JsonProperty("protein")
        public double protein = 0;

        @JsonProperty("fat")
        public double fat = 0;

        @JsonProperty("carbs")
        public double carbs = 0;

        @JsonProperty("sugar")
        public double sugar = 0;

        public NutritionProgress() {
        }

        public void addNutrition(double grams, List<Object> nutritionData) {
            if (nutritionData != null && nutritionData.size() >= 5) {
                try {
                    double baseGrams = 100.0;
                    double ratio = grams / baseGrams;
                    this.calories += parseDouble(nutritionData.get(0)) * ratio;
                    this.protein += parseDouble(nutritionData.get(1)) * ratio;
                    this.fat += parseDouble(nutritionData.get(2)) * ratio;
                    this.carbs += parseDouble(nutritionData.get(3)) * ratio;
                    this.sugar += parseDouble(nutritionData.get(4)) * ratio;
                } catch (Exception e) {
                    System.err.println("영양정보 계산 오류: " + e.getMessage());
                }
            }
        }

        public void subtractNutrition(double grams, List<Object> nutritionData) {
            if (nutritionData != null && nutritionData.size() >= 5) {
                try {
                    double baseGrams = 100.0;
                    double ratio = grams / baseGrams;
                    this.calories -= parseDouble(nutritionData.get(0)) * ratio;
                    this.protein -= parseDouble(nutritionData.get(1)) * ratio;
                    this.fat -= parseDouble(nutritionData.get(2)) * ratio;
                    this.carbs -= parseDouble(nutritionData.get(3)) * ratio;
                    this.sugar -= parseDouble(nutritionData.get(4)) * ratio;
                } catch (Exception e) {
                    System.err.println("영양정보 계산 오류: " + e.getMessage());
                }
            }
        }

        private double parseDouble(Object value) {
            if (value == null)
                return 0.0;
            try {
                return Double.parseDouble(value.toString());
            } catch (NumberFormatException e) {
                return 0.0;
            }
        }

        public void reset() {
            this.calories = 0;
            this.protein = 0;
            this.fat = 0;
            this.carbs = 0;
            this.sugar = 0;
        }
    }

    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class SelectedFood {
        @JsonProperty("foodName")
        public String foodName;

        @JsonProperty("grams")
        public double grams;

        @JsonProperty("nutritionData")
        public List<Object> nutritionData;

        public SelectedFood() {
        }

        public SelectedFood(String foodName, double grams, List<Object> nutritionData) {
            this.foodName = foodName;
            this.grams = grams;
            this.nutritionData = nutritionData != null ? new ArrayList<>(nutritionData) : new ArrayList<>();
        }

        @Override
        public String toString() {
            return String.format("%s - %.1fg", foodName != null ? foodName : "알 수 없음", grams);
        }
    }

    // 생성자
    public mainUI(String excelFilePath) {
        try {
            this.dataManager = new DataManager();

            ReadExcel readExcel = new ReadExcel();
            readExcel.readExcel(excelFilePath);
            this.searchEngine = new FoodSearchEngine(readExcel);
            this.currentDate = LocalDate.now();

            selectOrCreateProfile();
            initializeUI();
            loadTodayData();

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null,
                    "Excel 파일을 로드할 수 없습니다: " + e.getMessage(),
                    "오류", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
            System.exit(1);
        }
    }

    // 프로필 관리 메서드들
    private void selectOrCreateProfile() {
        List<String> existingProfiles = dataManager.getProfileList();

        if (existingProfiles.isEmpty()) {
            createNewProfile();
        } else {
            showProfileSelectionDialog(existingProfiles);
        }
    }

    private void showProfileSelectionDialog(List<String> existingProfiles) {
        String[] options = { "기존 프로필 선택", "새 프로필 생성" };
        int choice = JOptionPane.showOptionDialog(
                null,
                "어떻게 하시겠습니까?",
                "프로필 선택",
                JOptionPane.DEFAULT_OPTION,
                JOptionPane.QUESTION_MESSAGE,
                null,
                options,
                options[0]);

        if (choice == 0) {
            selectExistingProfile(existingProfiles);
        } else if (choice == 1) {
            createNewProfile();
        } else {
            System.exit(0);
        }
    }

    private void selectExistingProfile(List<String> existingProfiles) {
        String lastUsedProfile = dataManager.getLastUsedProfile();
        String defaultProfile = (lastUsedProfile != null && existingProfiles.contains(lastUsedProfile))
                ? lastUsedProfile
                : existingProfiles.get(0);

        String selectedProfile = (String) JOptionPane.showInputDialog(
                null,
                "사용할 프로필을 선택하세요:",
                "프로필 선택",
                JOptionPane.QUESTION_MESSAGE,
                null,
                existingProfiles.toArray(),
                defaultProfile);

        if (selectedProfile != null) {
            loadProfile(selectedProfile);
        } else {
            System.exit(0);
        }
    }

    private void createNewProfile() {
        String profileName = JOptionPane.showInputDialog(
                null,
                "새 프로필의 이름을 입력하세요:",
                "새 프로필 생성",
                JOptionPane.QUESTION_MESSAGE);

        if (profileName != null && !profileName.trim().isEmpty()) {
            profileName = profileName.trim();

            List<String> existingProfiles = dataManager.getProfileList();
            if (existingProfiles.contains(profileName)) {
                JOptionPane.showMessageDialog(null, "이미 존재하는 프로필 이름입니다.", "오류", JOptionPane.ERROR_MESSAGE);
                createNewProfile();
                return;
            }

            this.currentProfileName = profileName;
            this.userProfile = new UserProfile();
            this.goals = new NutritionGoals(2000, 50, 65, 300, 50);
            this.progress = new NutritionProgress();
            dailyDataMap.clear();

            dataManager.saveLastUsedProfile(profileName);
            showProfileSetupDialog();
        } else {
            System.exit(0);
        }
    }

    private void loadProfile(String profileName) {
        try {
            this.currentProfileName = profileName;

            UserProfile loadedProfile = dataManager.loadUserProfile(profileName);
            if (loadedProfile != null && loadedProfile.isValidProfile()) {
                this.userProfile = loadedProfile;
                System.out.println("유효한 프로필 로드: " + profileName);
            } else {
                this.userProfile = new UserProfile();
                System.out.println("새 프로필 생성: " + profileName);
            }

            NutritionGoals loadedGoals = dataManager.loadNutritionGoals(profileName);
            if (loadedGoals != null) {
                this.goals = loadedGoals;
            } else {
                this.goals = new NutritionGoals(2000, 50, 65, 300, 50);
            }

            Map<LocalDate, DailyNutritionData> loadedDailyData = dataManager.loadDailyData(profileName);
            dailyDataMap.clear();
            if (loadedDailyData != null && !loadedDailyData.isEmpty()) {
                dailyDataMap.putAll(loadedDailyData);
            }

            this.progress = new NutritionProgress();
            dataManager.saveLastUsedProfile(profileName);

            System.out.println("프로필 로드 완료: " + profileName);
        } catch (Exception e) {
            System.err.println("프로필 로드 중 오류 발생: " + e.getMessage());
            e.printStackTrace();

            this.userProfile = new UserProfile();
            this.goals = new NutritionGoals(2000, 50, 65, 300, 50);
            this.progress = new NutritionProgress();
        }
    }

    // 데이터 관리 메서드들 (null 체크 강화)
    private void saveAllData() {
        if (currentProfileName != null) {
            saveTodayData();
            dataManager.saveDailyData(dailyDataMap, currentProfileName);
            dataManager.saveUserProfile(userProfile, currentProfileName);
            dataManager.saveNutritionGoals(goals, currentProfileName);
            System.out.println("모든 데이터 저장 완료: " + currentProfileName);
        }
    }

    private void loadTodayData() {
        DailyNutritionData todayData = dailyDataMap.get(currentDate);

        if (selectedFoodsModel != null) {
            selectedFoodsModel.clear();
        }

        if (progress != null) {
            progress.reset();
        }

        if (todayData != null && selectedFoodsModel != null) {
            for (SelectedFood food : todayData.foods) {
                selectedFoodsModel.addElement(food);
                if (progress != null) {
                    progress.addNutrition(food.grams, food.nutritionData);
                }
            }
        }

        updateProgressDisplay();
        updateDateLabel();
    }

    private void saveTodayData() {
        if (selectedFoodsModel == null)
            return;

        List<SelectedFood> currentFoods = new ArrayList<>();
        for (int i = 0; i < selectedFoodsModel.size(); i++) {
            SelectedFood originalFood = selectedFoodsModel.getElementAt(i);
            currentFoods.add(new SelectedFood(originalFood.foodName, originalFood.grams,
                    new ArrayList<>(originalFood.nutritionData)));
        }

        NutritionProgress currentProgress = new NutritionProgress();
        if (progress != null) {
            currentProgress.calories = progress.calories;
            currentProgress.protein = progress.protein;
            currentProgress.fat = progress.fat;
            currentProgress.carbs = progress.carbs;
            currentProgress.sugar = progress.sugar;
        }

        DailyNutritionData todayData = new DailyNutritionData(currentFoods, currentProgress);
        dailyDataMap.put(currentDate, todayData);

        if (currentProfileName != null) {
            dataManager.saveDailyData(dailyDataMap, currentProfileName);
        }
    }

    public void switchToDate(LocalDate date) {
        if (date.equals(currentDate))
            return;
        saveTodayData();
        this.currentDate = date;
        loadTodayData();
    }

    private void updateDateLabel() {
        if (currentDateLabel == null) {
            return;
        }

        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy년 MM월 dd일 (E)", Locale.KOREAN);
        currentDateLabel.setText("현재 날짜: " + currentDate.format(formatter));
    }

    private void updateTitle() {
        setTitle("영양정보 추적 어플 - " + (currentProfileName != null ? currentProfileName : "프로필 없음"));
    }

    // 핵심 수정: null 체크가 포함된 updateProgressDisplay
    private void updateProgressDisplay() {
        // progressPanel이 null이면 아무것도 하지 않음 (지연 초기화)
        if (progressPanel == null) {
            System.out.println("progressPanel이 아직 초기화되지 않았습니다. 나중에 업데이트됩니다.");
            return;
        }

        progressPanel.removeAll();

        String[] labels = { "칼로리", "단백질", "지방", "탄수화물", "당류" };
        double[] current = {
                progress != null ? progress.calories : 0,
                progress != null ? progress.protein : 0,
                progress != null ? progress.fat : 0,
                progress != null ? progress.carbs : 0,
                progress != null ? progress.sugar : 0
        };
        double[] target = {
                goals != null ? goals.calories : 2000,
                goals != null ? goals.protein : 50,
                goals != null ? goals.fat : 65,
                goals != null ? goals.carbs : 300,
                goals != null ? goals.sugar : 50
        };
        String[] units = { "kcal", "g", "g", "g", "g" };
        Color[] colors = { Color.RED, Color.BLUE, Color.ORANGE, Color.GREEN, Color.MAGENTA };

        for (int i = 0; i < labels.length; i++) {
            JPanel nutrientPanel = createNutrientProgressPanel(labels[i], current[i], target[i], units[i], colors[i]);
            progressPanel.add(nutrientPanel);
        }

        progressPanel.revalidate();
        progressPanel.repaint();
    }

    // UI 초기화
    private void initializeUI() {
        updateTitle();
        setupWindowCloseHandler();
        addMenuBar();
        setLayout(new BorderLayout());

        JPanel mainPanel = new JPanel(new BorderLayout());
        JPanel topPanel = new JPanel(new BorderLayout());

        topPanel.add(createDatePanel(), BorderLayout.NORTH);
        topPanel.add(createInputPanel(), BorderLayout.CENTER);
        mainPanel.add(topPanel, BorderLayout.NORTH);

        JPanel centerPanel = new JPanel(new BorderLayout());
        JPanel topCenterPanel = new JPanel(new GridLayout(1, 2, 10, 0));
        topCenterPanel.add(createSearchResultPanel());
        topCenterPanel.add(createNutritionPanel());
        centerPanel.add(topCenterPanel, BorderLayout.NORTH);

        progressPanel = createProgressPanel();
        centerPanel.add(progressPanel, BorderLayout.CENTER);
        mainPanel.add(centerPanel, BorderLayout.CENTER);
        mainPanel.add(createSelectedFoodsPanel(), BorderLayout.SOUTH);

        add(mainPanel);
        setSize(1200, 900);
        setLocationRelativeTo(null);
        setVisible(true);

        // UI 초기화 완료 후 진행률 업데이트
        updateProgressDisplay();
    }

    private void setupWindowCloseHandler() {
        setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent windowEvent) {
                int option = JOptionPane.showConfirmDialog(
                        mainUI.this,
                        "애플리케이션을 종료하시겠습니까?\n(데이터는 자동으로 저장됩니다)",
                        "종료 확인",
                        JOptionPane.YES_NO_OPTION);
                if (option == JOptionPane.YES_OPTION) {
                    saveAllData();
                    System.exit(0);
                }
            }
        });
    }

    private void addMenuBar() {
        JMenuBar menuBar = new JMenuBar();

        JMenu fileMenu = new JMenu("파일");
        JMenuItem saveItem = new JMenuItem("저장");
        saveItem.addActionListener(_ -> {
            saveAllData();
            JOptionPane.showMessageDialog(this, "데이터가 저장되었습니다!");
        });

        JMenuItem backupItem = new JMenuItem("백업");
        backupItem.addActionListener(_ -> {
            if (currentProfileName != null) {
                dataManager.backupProfile(currentProfileName);
                JOptionPane.showMessageDialog(this, "백업이 완료되었습니다!");
            }
        });

        fileMenu.add(saveItem);
        fileMenu.add(backupItem);

        JMenu profileMenu = new JMenu("프로필");
        JMenuItem switchProfileItem = new JMenuItem("프로필 전환");
        switchProfileItem.addActionListener(_ -> switchProfile());

        JMenuItem newProfileItem = new JMenuItem("새 프로필 생성");
        newProfileItem.addActionListener(_ -> {
            saveAllData();
            createNewProfile();
            loadTodayData();
            updateTitle();
        });

        JMenuItem deleteProfileItem = new JMenuItem("프로필 삭제");
        deleteProfileItem.addActionListener(_ -> deleteCurrentProfile());

        profileMenu.add(switchProfileItem);
        profileMenu.add(newProfileItem);
        profileMenu.add(deleteProfileItem);

        menuBar.add(fileMenu);
        menuBar.add(profileMenu);
        setJMenuBar(menuBar);
    }

    // UI 컴포넌트 생성 메서드들
    private JPanel createDatePanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBorder(BorderFactory.createTitledBorder("날짜 관리"));

        currentDateLabel = new JLabel();
        currentDateLabel.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 14));
        currentDateLabel.setHorizontalAlignment(SwingConstants.CENTER);
        panel.add(currentDateLabel, BorderLayout.CENTER);

        JButton calendarButton = new JButton("달력 열기");
        calendarButton.addActionListener(_ -> openCalendar());
        panel.add(calendarButton, BorderLayout.EAST);

        return panel;
    }

    private void openCalendar() {
        if (calendarUI == null) {
            calendarUI = new CalendarUI(this);
        }
        calendarUI.setVisible(true);
        calendarUI.toFront();
    }

    private JPanel createInputPanel() {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBorder(BorderFactory.createTitledBorder("음식 검색 및 입력"));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);

        gbc.gridx = 0;
        gbc.gridy = 0;
        panel.add(new JLabel("음식명:"), gbc);

        gbc.gridx = 1;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.weightx = 1.0;
        searchField = new JTextField(20);
        searchField.getDocument().addDocumentListener(new DocumentListener() {
            public void insertUpdate(DocumentEvent e) {
                performSearch();
            }

            public void removeUpdate(DocumentEvent e) {
                performSearch();
            }

            public void changedUpdate(DocumentEvent e) {
                performSearch();
            }
        });
        panel.add(searchField, gbc);

        gbc.gridx = 2;
        gbc.fill = GridBagConstraints.NONE;
        gbc.weightx = 0;
        panel.add(new JLabel("그램:"), gbc);
        gbc.gridx = 3;
        gramField = new JTextField(10);
        panel.add(gramField, gbc);

        gbc.gridx = 4;
        addButton = new JButton("추가");
        addButton.setEnabled(false);
        addButton.addActionListener(_ -> addSelectedFood());
        panel.add(addButton, gbc);

        gbc.gridx = 5;
        JButton goalButton = new JButton("목표 설정");
        goalButton.addActionListener(_ -> showGoalSettingDialog());
        panel.add(goalButton, gbc);

        gbc.gridx = 6;
        profileButton = new JButton("프로필 관리");
        profileButton.addActionListener(_ -> showProfileManagementDialog());
        panel.add(profileButton, gbc);

        gbc.gridx = 7;
        weeklyUpdateButton = new JButton("주간 업데이트");
        weeklyUpdateButton.addActionListener(_ -> showWeeklyUpdateDialog());
        panel.add(weeklyUpdateButton, gbc);

        return panel;
    }

    private JPanel createSearchResultPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBorder(BorderFactory.createTitledBorder("검색 결과"));

        listModel = new DefaultListModel<>();
        suggestionList = new JList<>(listModel);
        suggestionList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        suggestionList.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if (e.getClickCount() == 1) {
                    showNutritionInfo();
                } else if (e.getClickCount() == 2) {
                    selectFood();
                }
            }
        });

        JScrollPane scrollPane = new JScrollPane(suggestionList);
        scrollPane.setPreferredSize(new Dimension(400, 200));
        panel.add(scrollPane, BorderLayout.CENTER);

        JLabel infoLabel = new JLabel("<html><center>더블클릭으로 음식 선택<br/>단일클릭으로 영양정보 확인</center></html>");
        infoLabel.setHorizontalAlignment(SwingConstants.CENTER);
        panel.add(infoLabel, BorderLayout.SOUTH);

        return panel;
    }

    private JPanel createNutritionPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBorder(BorderFactory.createTitledBorder("영양정보"));

        nutritionArea = new JTextArea();
        nutritionArea.setEditable(false);
        nutritionArea.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 12));

        JScrollPane scrollPane = new JScrollPane(nutritionArea);
        scrollPane.setPreferredSize(new Dimension(400, 200));
        panel.add(scrollPane, BorderLayout.CENTER);

        return panel;
    }

    private JPanel createProgressPanel() {
        JPanel panel = new JPanel(new GridLayout(5, 1, 5, 5));
        panel.setBorder(BorderFactory.createTitledBorder("영양 섭취 진행률"));
        return panel;
    }

    private JPanel createSelectedFoodsPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBorder(BorderFactory.createTitledBorder("선택된 음식들"));

        selectedFoodsModel = new DefaultListModel<>();
        selectedFoodsList = new JList<>(selectedFoodsModel);
        selectedFoodsList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

        JScrollPane scrollPane = new JScrollPane(selectedFoodsList);
        scrollPane.setPreferredSize(new Dimension(0, 150));
        panel.add(scrollPane, BorderLayout.CENTER);

        JPanel buttonPanel = new JPanel(new GridLayout(2, 1, 5, 5));
        JButton removeButton = new JButton("선택 항목 삭제");
        removeButton.addActionListener(_ -> removeSelectedFood());
        buttonPanel.add(removeButton);

        JButton clearButton = new JButton("전체 초기화");
        clearButton.addActionListener(_ -> clearAllFoods());
        buttonPanel.add(clearButton);

        panel.add(buttonPanel, BorderLayout.EAST);
        return panel;
    }

    // 음식 관련 메서드들
    private void performSearch() {
        String searchTerm = searchField.getText().trim();
        listModel.clear();
        nutritionArea.setText("");
        addButton.setEnabled(false);

        if (searchTerm.isEmpty())
            return;

        List<FoodSearchEngine.SearchResult> results = searchEngine.searchSimilarFoods(searchTerm, 10);
        for (FoodSearchEngine.SearchResult result : results) {
            listModel.addElement(result);
        }

        if (!results.isEmpty()) {
            suggestionList.setSelectedIndex(0);
            showNutritionInfo();
        }
    }

    private void showNutritionInfo() {
        FoodSearchEngine.SearchResult selected = suggestionList.getSelectedValue();
        if (selected != null) {
            displayNutritionInfo(selected.foodName, selected.nutritionData);
            addButton.setEnabled(true);
        }
    }

    private void selectFood() {
        FoodSearchEngine.SearchResult selected = suggestionList.getSelectedValue();
        if (selected != null) {
            searchField.setText(selected.foodName);
            gramField.requestFocus();
            addButton.setEnabled(true);
        }
    }

    private void addSelectedFood() {
        String foodName = searchField.getText().trim();
        String gramText = gramField.getText().trim();

        if (foodName.isEmpty()) {
            JOptionPane.showMessageDialog(this, "음식명을 입력해주세요.", "입력 오류", JOptionPane.WARNING_MESSAGE);
            return;
        }

        if (gramText.isEmpty()) {
            JOptionPane.showMessageDialog(this, "그램 수를 입력해주세요.", "입력 오류", JOptionPane.WARNING_MESSAGE);
            return;
        }

        try {
            double grams = Double.parseDouble(gramText);
            if (grams <= 0) {
                JOptionPane.showMessageDialog(this, "그램 수는 0보다 커야 합니다.", "입력 오류", JOptionPane.WARNING_MESSAGE);
                return;
            }

            List<Object> nutritionData = searchEngine.getExactNutrition(foodName);
            if (nutritionData == null) {
                JOptionPane.showMessageDialog(this, "해당 음식의 영양정보를 찾을 수 없습니다.", "검색 오류", JOptionPane.WARNING_MESSAGE);
                return;
            }

            SelectedFood selectedFood = new SelectedFood(foodName, grams, nutritionData);
            selectedFoodsModel.addElement(selectedFood);
            progress.addNutrition(grams, nutritionData);
            updateProgressDisplay();
            saveTodayData();

            searchField.setText("");
            gramField.setText("");
            listModel.clear();
            nutritionArea.setText("");
            addButton.setEnabled(false);

            JOptionPane.showMessageDialog(this, "음식이 추가되었습니다!");

        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "올바른 숫자를 입력해주세요.", "입력 오류", JOptionPane.WARNING_MESSAGE);
        }
    }

    private void removeSelectedFood() {
        int selectedIndex = selectedFoodsList.getSelectedIndex();
        if (selectedIndex >= 0) {
            SelectedFood selectedFood = selectedFoodsModel.getElementAt(selectedIndex);
            progress.subtractNutrition(selectedFood.grams, selectedFood.nutritionData);
            selectedFoodsModel.removeElementAt(selectedIndex);
            updateProgressDisplay();
            saveTodayData();
            JOptionPane.showMessageDialog(this, "선택된 음식이 삭제되었습니다.");
        } else {
            JOptionPane.showMessageDialog(this, "삭제할 음식을 선택해주세요.", "선택 오류", JOptionPane.WARNING_MESSAGE);
        }
    }

    private void clearAllFoods() {
        if (selectedFoodsModel.isEmpty()) {
            JOptionPane.showMessageDialog(this, "삭제할 음식이 없습니다.");
            return;
        }

        int confirm = JOptionPane.showConfirmDialog(this, "모든 음식을 삭제하시겠습니까?", "전체 삭제 확인", JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            selectedFoodsModel.clear();
            progress.reset();
            updateProgressDisplay();
            saveTodayData();
            JOptionPane.showMessageDialog(this, "모든 음식이 삭제되었습니다.");
        }
    }

    private JPanel createNutrientProgressPanel(String label, double current, double target, String unit, Color color) {
        JPanel panel = new JPanel(new BorderLayout());
        int percentage = target > 0 ? (int) Math.min(100, (current / target) * 100) : 0;

        JLabel nameLabel = new JLabel(
                String.format("%s: %.1f/%.0f %s (%d%%)", label, current, target, unit, percentage));
        nameLabel.setPreferredSize(new Dimension(200, 25));

        JProgressBar progressBar = new JProgressBar(0, 100);
        progressBar.setValue(percentage);
        progressBar.setStringPainted(true);
        progressBar.setForeground(percentage > 100 ? Color.RED : color);

        panel.add(nameLabel, BorderLayout.WEST);
        panel.add(progressBar, BorderLayout.CENTER);
        return panel;
    }

    private void displayNutritionInfo(String foodName, List<Object> nutritionData) {
        StringBuilder sb = new StringBuilder();
        sb.append("=== ").append(foodName).append(" ===\n\n");
        String[] headers = { "에너지(kcal)", "단백질(g)", "지방(g)", "탄수화물(g)", "당류(g)" };

        for (int i = 0; i < nutritionData.size() && i < headers.length; i++) {
            Object value = nutritionData.get(i);
            sb.append(headers[i]).append(": ");
            sb.append(value != null ? value.toString() : "정보 없음");
            sb.append("\n");
        }
        nutritionArea.setText(sb.toString());
    }

    // 프로필 관련 메서드들
    private void showProfileSetupDialog() {
        JPanel panel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.anchor = GridBagConstraints.WEST;

        JTextField nameField = new JTextField(15);
        JTextField ageField = new JTextField(10);
        JComboBox<String> genderCombo = new JComboBox<>(new String[] { "남성", "여성" });
        JTextField heightField = new JTextField(10);
        JTextField weightField = new JTextField(10);
        JTextField muscleField = new JTextField(10);
        JTextField fatField = new JTextField(10);
        JComboBox<UserProfile.ActivityLevel> activityCombo = new JComboBox<>(UserProfile.ActivityLevel.values());

        int row = 0;
        gbc.gridx = 0;
        gbc.gridy = row;
        panel.add(new JLabel("이름:"), gbc);
        gbc.gridx = 1;
        panel.add(nameField, gbc);

        row++;
        gbc.gridx = 0;
        gbc.gridy = row;
        panel.add(new JLabel("나이:"), gbc);
        gbc.gridx = 1;
        panel.add(ageField, gbc);

        row++;
        gbc.gridx = 0;
        gbc.gridy = row;
        panel.add(new JLabel("성별:"), gbc);
        gbc.gridx = 1;
        panel.add(genderCombo, gbc);

        row++;
        gbc.gridx = 0;
        gbc.gridy = row;
        panel.add(new JLabel("키 (cm):"), gbc);
        gbc.gridx = 1;
        panel.add(heightField, gbc);

        row++;
        gbc.gridx = 0;
        gbc.gridy = row;
        panel.add(new JLabel("체중 (kg):"), gbc);
        gbc.gridx = 1;
        panel.add(weightField, gbc);

        row++;
        gbc.gridx = 0;
        gbc.gridy = row;
        panel.add(new JLabel("근육량 (kg):"), gbc);
        gbc.gridx = 1;
        panel.add(muscleField, gbc);

        row++;
        gbc.gridx = 0;
        gbc.gridy = row;
        panel.add(new JLabel("체지방률 (%):"), gbc);
        gbc.gridx = 1;
        panel.add(fatField, gbc);

        row++;
        gbc.gridx = 0;
        gbc.gridy = row;
        panel.add(new JLabel("활동 수준:"), gbc);
        gbc.gridx = 1;
        panel.add(activityCombo, gbc);

        int result = JOptionPane.showConfirmDialog(this, panel, "프로필 설정", JOptionPane.OK_CANCEL_OPTION,
                JOptionPane.PLAIN_MESSAGE);

        if (result == JOptionPane.OK_OPTION) {
            try {
                userProfile.setName(nameField.getText().trim());
                userProfile.setAge(Integer.parseInt(ageField.getText()));
                userProfile.setGender((String) genderCombo.getSelectedItem());
                userProfile.setHeight(Double.parseDouble(heightField.getText()));
                userProfile.setWeight(Double.parseDouble(weightField.getText()));
                userProfile.setMuscleMass(Double.parseDouble(muscleField.getText()));
                userProfile.setBodyFatPercentage(Double.parseDouble(fatField.getText()));
                userProfile.setActivityLevel((UserProfile.ActivityLevel) activityCombo.getSelectedItem());

                dataManager.saveUserProfile(userProfile, currentProfileName);
                showGoalRecommendationDialog();

            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(this, "올바른 숫자를 입력해주세요.", "입력 오류", JOptionPane.WARNING_MESSAGE);
                showProfileSetupDialog();
            }
        } else {
            System.exit(0);
        }
    }

    private void showGoalRecommendationDialog() {
        UserProfile.FitnessGoal recommended = userProfile.getRecommendedGoal();

        StringBuilder message = new StringBuilder();
        message.append("=== 신체 분석 결과 ===\n\n");
        message.append(String.format("BMI: %.1f (%s)\n", userProfile.calculateBMI(), userProfile.getBMIStatus()));
        message.append(String.format("기초대사율: %.0f kcal\n", userProfile.calculateBMR()));
        message.append(String.format("일일 소모 칼로리: %.0f kcal\n\n", userProfile.calculateTDEE()));
        message.append("=== 추천 목표 ===\n");
        message.append(String.format("추천 목표: %s\n\n", recommended.getDescription()));
        message.append("이 목표로 설정하시겠습니까?\n(아니오를 선택하면 직접 목표를 선택할 수 있습니다)");

        int choice = JOptionPane.showConfirmDialog(this, message.toString(), "목표 추천", JOptionPane.YES_NO_OPTION,
                JOptionPane.INFORMATION_MESSAGE);

        if (choice == JOptionPane.YES_OPTION) {
            userProfile.setFitnessGoal(recommended);
            updateNutritionGoalsFromProfile();
        } else {
            showGoalSelectionDialog();
        }
    }

    private void showGoalSelectionDialog() {
        UserProfile.FitnessGoal[] goals = UserProfile.FitnessGoal.values();
        UserProfile.FitnessGoal selected = (UserProfile.FitnessGoal) JOptionPane.showInputDialog(
                this, "목표를 선택하세요:", "목표 설정", JOptionPane.QUESTION_MESSAGE, null, goals, goals[0]);

        if (selected != null) {
            userProfile.setFitnessGoal(selected);
            updateNutritionGoalsFromProfile();
        } else {
            showGoalSelectionDialog();
        }
    }

    private void updateNutritionGoalsFromProfile() {
        goals.calories = userProfile.calculateTargetCalories();
        goals.protein = userProfile.calculateProteinTarget();
        goals.fat = userProfile.calculateFatTarget();
        goals.carbs = userProfile.calculateCarbTarget();
        goals.sugar = userProfile.calculateSugarTarget();

        updateProgressDisplay();

        if (currentProfileName != null) {
            dataManager.saveNutritionGoals(goals, currentProfileName);
        }

        StringBuilder message = new StringBuilder();
        message.append("=== 영양 목표가 설정되었습니다 ===\n\n");
        message.append(String.format("프로필: %s\n", currentProfileName));
        message.append(String.format("목표: %s\n", userProfile.getFitnessGoal().getDescription()));
        message.append(String.format("칼로리: %.0f kcal\n", goals.calories));
        message.append(String.format("단백질: %.0f g\n", goals.protein));
        message.append(String.format("지방: %.0f g\n", goals.fat));
        message.append(String.format("탄수화물: %.0f g\n", goals.carbs));
        message.append(String.format("당류: %.0f g\n", goals.sugar));

        JOptionPane.showMessageDialog(this, message.toString(), "목표 설정 완료", JOptionPane.INFORMATION_MESSAGE);
    }

    private void showGoalSettingDialog() {
        if (userProfile != null && userProfile.getName() != null && !userProfile.getName().isEmpty()) {
            String[] options = { "프로필 기반 자동 설정", "수동 설정" };
            int choice = JOptionPane.showOptionDialog(this, "목표 설정 방법을 선택하세요:", "목표 설정",
                    JOptionPane.DEFAULT_OPTION, JOptionPane.QUESTION_MESSAGE, null, options, options[0]);

            if (choice == 0) {
                updateNutritionGoalsFromProfile();
                return;
            }
        }

        JPanel panel = new JPanel(new GridLayout(5, 2, 5, 5));
        JTextField caloriesField = new JTextField(String.valueOf((int) goals.calories));
        JTextField proteinField = new JTextField(String.valueOf((int) goals.protein));
        JTextField fatField = new JTextField(String.valueOf((int) goals.fat));
        JTextField carbsField = new JTextField(String.valueOf((int) goals.carbs));
        JTextField sugarField = new JTextField(String.valueOf((int) goals.sugar));

        panel.add(new JLabel("일일 칼로리 목표 (kcal):"));
        panel.add(caloriesField);
        panel.add(new JLabel("단백질 목표 (g):"));
        panel.add(proteinField);
        panel.add(new JLabel("지방 목표 (g):"));
        panel.add(fatField);
        panel.add(new JLabel("탄수화물 목표 (g):"));
        panel.add(carbsField);
        panel.add(new JLabel("당류 목표 (g):"));
        panel.add(sugarField);

        int result = JOptionPane.showConfirmDialog(this, panel, "영양 목표 설정", JOptionPane.OK_CANCEL_OPTION,
                JOptionPane.PLAIN_MESSAGE);

        if (result == JOptionPane.OK_OPTION) {
            try {
                goals.calories = Double.parseDouble(caloriesField.getText());
                goals.protein = Double.parseDouble(proteinField.getText());
                goals.fat = Double.parseDouble(fatField.getText());
                goals.carbs = Double.parseDouble(carbsField.getText());
                goals.sugar = Double.parseDouble(sugarField.getText());
                updateProgressDisplay();
                if (currentProfileName != null) {
                    dataManager.saveNutritionGoals(goals, currentProfileName);
                }
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(this, "올바른 숫자를 입력해주세요.", "입력 오류", JOptionPane.WARNING_MESSAGE);
                showGoalSettingDialog();
            }
        }
    }

    private void showProfileManagementDialog() {
        String[] options = { "프로필 보기", "목표 변경", "주간 업데이트", "진행률 분석", "현재 프로필 삭제", "다른 프로필 삭제" };
        int choice = JOptionPane.showOptionDialog(this, "원하는 작업을 선택하세요:", "프로필 관리",
                JOptionPane.DEFAULT_OPTION, JOptionPane.QUESTION_MESSAGE, null, options, options[0]);

        switch (choice) {
            case 0:
                showProfileInfo();
                break;
            case 1:
                showGoalSelectionDialog();
                break;
            case 2:
                showWeeklyUpdateDialog();
                break;
            case 3:
                showProgressAnalysis();
                break;
            case 4:
                deleteCurrentProfile();
                break;
            case 5:
                deleteSelectedProfile();
                break; // 새로운 기능
        }
    }

    // 선택한 프로필 삭제 기능
    private void deleteSelectedProfile() {
        List<String> allProfiles = dataManager.getProfileList();
        if (allProfiles.size() <= 1) {
            JOptionPane.showMessageDialog(this, "삭제할 수 있는 다른 프로필이 없습니다.", "알림", JOptionPane.INFORMATION_MESSAGE);
            return;
        }

        // 현재 프로필 제외한 목록 생성
        List<String> otherProfiles = new ArrayList<>(allProfiles);
        otherProfiles.remove(currentProfileName);

        String selectedProfile = (String) JOptionPane.showInputDialog(
                this,
                "삭제할 프로필을 선택하세요:",
                "프로필 삭제",
                JOptionPane.QUESTION_MESSAGE,
                null,
                otherProfiles.toArray(),
                otherProfiles.get(0));

        if (selectedProfile != null) {
            int confirm = JOptionPane.showConfirmDialog(
                    this,
                    String.format("정말로 '%s' 프로필을 삭제하시겠습니까?\n모든 데이터가 영구적으로 삭제됩니다.", selectedProfile),
                    "프로필 삭제 확인",
                    JOptionPane.YES_NO_OPTION,
                    JOptionPane.WARNING_MESSAGE);

            if (confirm == JOptionPane.YES_OPTION) {
                boolean success = dataManager.deleteProfile(selectedProfile);
                if (success) {
                    JOptionPane.showMessageDialog(this, "프로필이 삭제되었습니다: " + selectedProfile);
                } else {
                    JOptionPane.showMessageDialog(this, "프로필 삭제에 실패했습니다.", "오류", JOptionPane.ERROR_MESSAGE);
                }
            }
        }
    }

    private void showProfileInfo() {
        StringBuilder info = new StringBuilder();
        info.append("=== 프로필 정보 ===\n\n");
        info.append(String.format("프로필명: %s\n", currentProfileName));
        info.append(String.format("이름: %s\n", userProfile.getName()));
        info.append(String.format("나이: %d세\n", userProfile.getAge()));
        info.append(String.format("성별: %s\n", userProfile.getGender()));
        info.append(String.format("키: %.1f cm\n", userProfile.getHeight()));
        info.append(String.format("체중: %.1f kg\n", userProfile.getWeight()));
        info.append(String.format("근육량: %.1f kg\n", userProfile.getMuscleMass()));
        info.append(String.format("체지방률: %.1f%%\n", userProfile.getBodyFatPercentage()));
        info.append(String.format("활동 수준: %s\n\n", userProfile.getActivityLevel().getDescription()));
        info.append("=== 신체 지수 ===\n");
        info.append(String.format("BMI: %.1f (%s)\n", userProfile.calculateBMI(), userProfile.getBMIStatus()));
        info.append(String.format("기초대사율: %.0f kcal\n", userProfile.calculateBMR()));
        info.append(String.format("일일 소모 칼로리: %.0f kcal\n\n", userProfile.calculateTDEE()));
        info.append("=== 현재 목표 ===\n");
        info.append(String.format("목표: %s\n", userProfile.getFitnessGoal().getDescription()));
        info.append(String.format("마지막 업데이트: %s\n", userProfile.getLastUpdated()));

        JOptionPane.showMessageDialog(this, info.toString(), "프로필 정보", JOptionPane.INFORMATION_MESSAGE);
    }

    private void showWeeklyUpdateDialog() {
        long daysSinceUpdate = ChronoUnit.DAYS.between(userProfile.getLastUpdated(), LocalDate.now());

        if (daysSinceUpdate < 7) {
            int choice = JOptionPane.showConfirmDialog(this,
                    String.format("마지막 업데이트로부터 %d일이 지났습니다.\n일주일이 지나지 않았지만 업데이트하시겠습니까?", daysSinceUpdate),
                    "주간 업데이트", JOptionPane.YES_NO_OPTION);
            if (choice != JOptionPane.YES_OPTION)
                return;
        }

        JPanel panel = new JPanel(new GridLayout(3, 2, 5, 5));
        JTextField weightField = new JTextField(String.valueOf(userProfile.getWeight()));
        JTextField muscleField = new JTextField(String.valueOf(userProfile.getMuscleMass()));
        JTextField fatField = new JTextField(String.valueOf(userProfile.getBodyFatPercentage()));

        panel.add(new JLabel("현재 체중 (kg):"));
        panel.add(weightField);
        panel.add(new JLabel("현재 근육량 (kg):"));
        panel.add(muscleField);
        panel.add(new JLabel("현재 체지방률 (%):"));
        panel.add(fatField);

        int result = JOptionPane.showConfirmDialog(this, panel, "주간 신체 정보 업데이트", JOptionPane.OK_CANCEL_OPTION,
                JOptionPane.PLAIN_MESSAGE);

        if (result == JOptionPane.OK_OPTION) {
            try {
                double weight = Double.parseDouble(weightField.getText());
                double muscle = Double.parseDouble(muscleField.getText());
                double fat = Double.parseDouble(fatField.getText());

                userProfile.addWeeklyRecord(weight, muscle, fat);
                dataManager.saveUserProfile(userProfile, currentProfileName);

                UserProfile.FitnessGoal newRecommendation = userProfile.getRecommendedGoal();
                if (newRecommendation != userProfile.getFitnessGoal()) {
                    int choice = JOptionPane.showConfirmDialog(this,
                            String.format("신체 변화에 따라 추천 목표가 '%s'로 변경되었습니다.\n목표를 변경하시겠습니까?",
                                    newRecommendation.getDescription()),
                            "목표 재설정", JOptionPane.YES_NO_OPTION);

                    if (choice == JOptionPane.YES_OPTION) {
                        userProfile.setFitnessGoal(newRecommendation);
                        dataManager.saveUserProfile(userProfile, currentProfileName);
                    }
                }

                updateNutritionGoalsFromProfile();
                JOptionPane.showMessageDialog(this, "주간 업데이트가 완료되었습니다!", "업데이트 완료", JOptionPane.INFORMATION_MESSAGE);

            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(this, "올바른 숫자를 입력해주세요.", "입력 오류", JOptionPane.WARNING_MESSAGE);
            }
        }
    }

    private void showProgressAnalysis() {
        String analysis = userProfile.getProgressAnalysis();
        JOptionPane.showMessageDialog(this, analysis, "진행률 분석", JOptionPane.INFORMATION_MESSAGE);
    }

    private void switchProfile() {
        List<String> existingProfiles = dataManager.getProfileList();
        if (existingProfiles.size() <= 1) {
            JOptionPane.showMessageDialog(this, "전환할 다른 프로필이 없습니다.", "알림", JOptionPane.INFORMATION_MESSAGE);
            return;
        }

        saveAllData();

        existingProfiles.remove(currentProfileName);
        String selectedProfile = (String) JOptionPane.showInputDialog(
                this,
                "전환할 프로필을 선택하세요:",
                "프로필 전환",
                JOptionPane.QUESTION_MESSAGE,
                null,
                existingProfiles.toArray(),
                existingProfiles.get(0));

        if (selectedProfile != null) {
            loadProfile(selectedProfile);
            loadTodayData();
            updateTitle();
            JOptionPane.showMessageDialog(this, "프로필이 전환되었습니다: " + selectedProfile);
        }
    }

    private void deleteCurrentProfile() {
        List<String> allProfiles = dataManager.getProfileList();
        if (allProfiles.size() <= 1) {
            JOptionPane.showMessageDialog(this, "마지막 프로필은 삭제할 수 없습니다.", "오류", JOptionPane.ERROR_MESSAGE);
            return;
        }

        int confirm = JOptionPane.showConfirmDialog(
                this,
                String.format("정말로 '%s' 프로필을 삭제하시겠습니까?\n모든 데이터가 영구적으로 삭제됩니다.", currentProfileName),
                "프로필 삭제 확인",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.WARNING_MESSAGE);

        if (confirm == JOptionPane.YES_OPTION) {
            String profileToDelete = currentProfileName;
            allProfiles.remove(currentProfileName);
            loadProfile(allProfiles.get(0));
            dataManager.deleteProfile(profileToDelete);
            loadTodayData();
            updateTitle();
            JOptionPane.showMessageDialog(this, "프로필이 삭제되었습니다: " + profileToDelete);
        }
    }

    // 공용 메서드들
    public static DailyNutritionData getDailyData(LocalDate date) {
        return dailyDataMap.get(date);
    }

    public NutritionGoals getGoals() {
        return goals;
    }

    @Override
    public void dispose() {
        saveAllData();
        super.dispose();
    }
}
