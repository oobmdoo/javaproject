package com.project.main;

import com.project.UI.mainUI;
import javax.swing.UIManager;

public class Kalculator {
    public static void main(String[] args) {

        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e) {
            e.printStackTrace();
        }

        try {
            String excelPath = "C:\\Users\\jihyu\\Desktop\\Project\\db\\main.xlsx";

            new mainUI(excelPath);
        } catch (Exception e) {
            e.printStackTrace();

        }
        System.out.println("Hello World!");
    }
}