package com.project.method;

import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Iterator;
import java.util.ArrayList;
import java.util.List;

public class ReadExcel {
    public List<Pair<String, List<Object>>> foodNutritionList = new ArrayList<>();

    public void readExcel(String filePath) throws IOException {
        try (FileInputStream fis = new FileInputStream(new File(filePath));
                Workbook workbook = new XSSFWorkbook(fis)) {

            Sheet sheet = workbook.getSheetAt(0);
            Iterator<Row> rowIterator = sheet.iterator();

            if (rowIterator.hasNext()) {
                rowIterator.next();
            }

            while (rowIterator.hasNext()) {
                Row row = rowIterator.next();
                List<Object> nutritionData = new ArrayList<>();
                String foodName = "";

                for (Cell cell : row) {

                    if (cell.getColumnIndex() == 0) {
                        foodName = cell.toString();
                    }

                    else {
                        switch (cell.getCellType()) {
                            case STRING:
                                nutritionData.add(cell.getStringCellValue());
                                break;
                            case NUMERIC:
                                nutritionData.add(cell.getNumericCellValue());
                                break;
                            default:
                                nutritionData.add(0);
                        }
                    }
                }

                if (!foodName.isEmpty()) {
                    foodNutritionList.add(new Pair<>(foodName, nutritionData));
                }
            }
        }
    }

    public static class Pair<A, B> {
        public final A first;
        public final B second;

        public Pair(A first, B second) {
            this.first = first;
            this.second = second;
        }
    }
}