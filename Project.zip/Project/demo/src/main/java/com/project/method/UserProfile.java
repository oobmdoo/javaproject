package com.project.method;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.time.LocalDate;
import java.util.HashMap;
import java.util.Map;

@JsonIgnoreProperties(ignoreUnknown = true)
public class UserProfile {

    // 기본 필드들
    @JsonProperty("name")
    private String name;

    @JsonProperty("age")
    private int age;

    @JsonProperty("gender")
    private String gender; // "남성" 또는 "여성"

    @JsonProperty("height")
    private double height; // cm

    @JsonProperty("weight")
    private double weight; // kg

    @JsonProperty("muscleMass")
    private double muscleMass; // kg

    @JsonProperty("bodyFatPercentage")
    private double bodyFatPercentage; // %

    @JsonProperty("lastUpdated")
    private LocalDate lastUpdated;

    @JsonProperty("fitnessGoal")
    private FitnessGoal fitnessGoal;

    @JsonProperty("activityLevel")
    private ActivityLevel activityLevel;

    @JsonProperty("weeklyRecords")
    private Map<LocalDate, WeeklyRecord> weeklyRecords;

    // 기본 생성자 (Jackson 필수)
    public UserProfile() {
        this.weeklyRecords = new HashMap<>();
        this.lastUpdated = LocalDate.now();
        this.fitnessGoal = FitnessGoal.MAINTENANCE;
        this.activityLevel = ActivityLevel.MODERATELY_ACTIVE;
    }

    // Fitness Goal Enum
    @JsonIgnoreProperties(ignoreUnknown = true)
    public enum FitnessGoal {
        @JsonProperty("DIET")
        DIET("다이어트", -0.5), // 주당 0.5kg 감량

        @JsonProperty("MAINTENANCE")
        MAINTENANCE("체중 유지", 0.0), // 체중 유지

        @JsonProperty("BULK_UP")
        BULK_UP("벌크업", 0.3), // 주당 0.3kg 증량

        @JsonProperty("LEAN_BULK")
        LEAN_BULK("린 벌크업", 0.2); // 주당 0.2kg 증량

        private final String description;
        private final double weeklyWeightChange; // kg per week

        FitnessGoal(String description, double weeklyWeightChange) {
            this.description = description;
            this.weeklyWeightChange = weeklyWeightChange;
        }

        public String getDescription() {
            return description;
        }

        public double getWeeklyWeightChange() {
            return weeklyWeightChange;
        }
    }

    // Activity Level Enum
    @JsonIgnoreProperties(ignoreUnknown = true)
    public enum ActivityLevel {
        @JsonProperty("SEDENTARY")
        SEDENTARY("좌식 생활", 1.2),

        @JsonProperty("LIGHTLY_ACTIVE")
        LIGHTLY_ACTIVE("가벼운 활동", 1.375),

        @JsonProperty("MODERATELY_ACTIVE")
        MODERATELY_ACTIVE("보통 활동", 1.55),

        @JsonProperty("VERY_ACTIVE")
        VERY_ACTIVE("활발한 활동", 1.725),

        @JsonProperty("EXTREMELY_ACTIVE")
        EXTREMELY_ACTIVE("매우 활발한 활동", 1.9);

        private final String description;
        private final double multiplier;

        ActivityLevel(String description, double multiplier) {
            this.description = description;
            this.multiplier = multiplier;
        }

        public String getDescription() {
            return description;
        }

        public double getMultiplier() {
            return multiplier;
        }
    }

    // Weekly Record 내부 클래스
    @JsonIgnoreProperties(ignoreUnknown = true)
    public static class WeeklyRecord {
        @JsonProperty("weight")
        private double weight;

        @JsonProperty("muscleMass")
        private double muscleMass;

        @JsonProperty("bodyFatPercentage")
        private double bodyFatPercentage;

        @JsonProperty("recordDate")
        private LocalDate recordDate;

        // 기본 생성자 (Jackson 필수)
        public WeeklyRecord() {
        }

        public WeeklyRecord(double weight, double muscleMass, double bodyFatPercentage, LocalDate recordDate) {
            this.weight = weight;
            this.muscleMass = muscleMass;
            this.bodyFatPercentage = bodyFatPercentage;
            this.recordDate = recordDate;
        }

        // Getters and Setters
        public double getWeight() {
            return weight;
        }

        public void setWeight(double weight) {
            this.weight = weight;
        }

        public double getMuscleMass() {
            return muscleMass;
        }

        public void setMuscleMass(double muscleMass) {
            this.muscleMass = muscleMass;
        }

        public double getBodyFatPercentage() {
            return bodyFatPercentage;
        }

        public void setBodyFatPercentage(double bodyFatPercentage) {
            this.bodyFatPercentage = bodyFatPercentage;
        }

        public LocalDate getRecordDate() {
            return recordDate;
        }

        public void setRecordDate(LocalDate recordDate) {
            this.recordDate = recordDate;
        }
    }

    // 계산 메서드들

    // BMR 계산 (Mifflin-St Jeor 공식)
    public double calculateBMR() {
        if (gender == null)
            return 0.0;

        if (gender.equals("남성")) {
            return 10 * weight + 6.25 * height - 5 * age + 5;
        } else {
            return 10 * weight + 6.25 * height - 5 * age - 161;
        }
    }

    // TDEE 계산 (Total Daily Energy Expenditure)
    public double calculateTDEE() {
        if (activityLevel == null)
            return calculateBMR();
        return calculateBMR() * activityLevel.getMultiplier();
    }

    // 목표 칼로리 계산
    public double calculateTargetCalories() {
        if (fitnessGoal == null)
            return calculateTDEE();

        double tdee = calculateTDEE();
        double weeklyCalorieChange = fitnessGoal.getWeeklyWeightChange() * 7700; // 1kg = 7700kcal
        double dailyCalorieAdjustment = weeklyCalorieChange / 7;

        return Math.max(tdee + dailyCalorieAdjustment, 1200); // 최소 1200kcal 보장
    }

    // 단백질 목표 계산 (체중 1kg당 1.6-2.2g)
    public double calculateProteinTarget() {
        if (fitnessGoal == null)
            return weight * 1.8;

        switch (fitnessGoal) {
            case BULK_UP:
            case LEAN_BULK:
                return weight * 2.0; // 벌크업 시 2.0g/kg
            case DIET:
                return weight * 2.2; // 다이어트 시 2.2g/kg (근손실 방지)
            default:
                return weight * 1.8; // 기본 1.8g/kg
        }
    }

    // 지방 목표 계산 (총 칼로리의 20-35%)
    public double calculateFatTarget() {
        double targetCalories = calculateTargetCalories();
        return (targetCalories * 0.25) / 9; // 지방 1g = 9kcal, 25%로 설정
    }

    // 탄수화물 목표 계산 (나머지 칼로리)
    public double calculateCarbTarget() {
        double targetCalories = calculateTargetCalories();
        double proteinCalories = calculateProteinTarget() * 4; // 단백질 1g = 4kcal
        double fatCalories = calculateFatTarget() * 9; // 지방 1g = 9kcal
        double remainingCalories = targetCalories - proteinCalories - fatCalories;

        return Math.max(remainingCalories / 4, 50); // 최소 50g 보장
    }

    // 당류 목표 계산 (탄수화물의 10% 이하)
    public double calculateSugarTarget() {
        return calculateCarbTarget() * 0.1;
    }

    // BMI 계산
    public double calculateBMI() {
        if (height <= 0)
            return 0.0;
        double heightInMeters = height / 100.0;
        return weight / (heightInMeters * heightInMeters);
    }

    // BMI 상태 반환
    public String getBMIStatus() {
        double bmi = calculateBMI();
        if (bmi < 18.5)
            return "저체중";
        else if (bmi < 23.0)
            return "정상";
        else if (bmi < 25.0)
            return "과체중";
        else
            return "비만";
    }

    // 추천 목표 계산
    public FitnessGoal getRecommendedGoal() {
        double bmi = calculateBMI();

        if (bmi < 18.5) {
            return FitnessGoal.BULK_UP; // 저체중 -> 벌크업
        } else if (bmi > 25.0) {
            return FitnessGoal.DIET; // 과체중/비만 -> 다이어트
        } else if (bodyFatPercentage > (gender != null && gender.equals("남성") ? 20 : 30)) {
            return FitnessGoal.DIET; // 체지방률 높음 -> 다이어트
        } else if (bodyFatPercentage < (gender != null && gender.equals("남성") ? 10 : 16)) {
            return FitnessGoal.LEAN_BULK; // 체지방률 낮음 -> 린 벌크업
        } else {
            return FitnessGoal.MAINTENANCE; // 정상 범위 -> 유지
        }
    }

    // 주간 기록 추가
    public void addWeeklyRecord(double weight, double muscleMass, double bodyFatPercentage) {
        LocalDate weekStart = LocalDate.now().minusDays(LocalDate.now().getDayOfWeek().getValue() - 1);
        WeeklyRecord record = new WeeklyRecord(weight, muscleMass, bodyFatPercentage, weekStart);

        if (weeklyRecords == null) {
            weeklyRecords = new HashMap<>();
        }

        weeklyRecords.put(weekStart, record);

        // 현재 정보 업데이트
        this.weight = weight;
        this.muscleMass = muscleMass;
        this.bodyFatPercentage = bodyFatPercentage;
        this.lastUpdated = LocalDate.now();
    }

    // 진행률 분석
    public String getProgressAnalysis() {
        if (weeklyRecords == null || weeklyRecords.size() < 2) {
            return "진행률 분석을 위해서는 최소 2주간의 데이터가 필요합니다.";
        }

        LocalDate currentWeek = LocalDate.now().minusDays(LocalDate.now().getDayOfWeek().getValue() - 1);
        LocalDate previousWeek = currentWeek.minusWeeks(1);

        WeeklyRecord current = weeklyRecords.get(currentWeek);
        WeeklyRecord previous = weeklyRecords.get(previousWeek);

        if (current == null || previous == null) {
            return "최근 2주간의 데이터가 없습니다.";
        }

        double weightChange = current.getWeight() - previous.getWeight();
        double muscleChange = current.getMuscleMass() - previous.getMuscleMass();
        double fatChange = current.getBodyFatPercentage() - previous.getBodyFatPercentage();

        StringBuilder analysis = new StringBuilder();
        analysis.append("=== 지난 주 대비 변화 ===\n\n");
        analysis.append(String.format("체중: %.1fkg (%+.1fkg)\n", current.getWeight(), weightChange));
        analysis.append(String.format("근육량: %.1fkg (%+.1fkg)\n", current.getMuscleMass(), muscleChange));
        analysis.append(String.format("체지방률: %.1f%% (%+.1f%%)\n\n", current.getBodyFatPercentage(), fatChange));

        // 목표 달성 여부 평가
        if (fitnessGoal != null) {
            double targetWeightChange = fitnessGoal.getWeeklyWeightChange();
            double tolerance = 0.2; // 허용 오차 200g

            if (Math.abs(weightChange - targetWeightChange) <= tolerance) {
                analysis.append("✅ 목표에 맞게 잘 진행되고 있습니다!\n");
            } else if (weightChange > targetWeightChange + tolerance) {
                analysis.append("⚠️ 체중 증가가 목표보다 빠릅니다. 칼로리 섭취를 조정해보세요.\n");
            } else {
                analysis.append("⚠️ 체중 변화가 목표보다 느립니다. 목표를 재검토해보세요.\n");
            }

            // 체성분 변화 분석
            if (muscleChange > 0 && fatChange < 0) {
                analysis.append("💪 근육량은 증가하고 체지방률은 감소했습니다. 훌륭합니다!\n");
            } else if (muscleChange < 0) {
                analysis.append("⚠️ 근육량이 감소했습니다. 단백질 섭취와 운동을 늘려보세요.\n");
            } else if (fatChange > 0) {
                analysis.append("⚠️ 체지방률이 증가했습니다. 칼로리 조절이 필요할 수 있습니다.\n");
            }
        }

        return analysis.toString();
    }

    // 데이터 검증
    public boolean isValidProfile() {
        return name != null && !name.trim().isEmpty() &&
                age > 0 && age < 150 &&
                height > 0 && height < 300 &&
                weight > 0 && weight < 500 &&
                muscleMass >= 0 && muscleMass <= weight &&
                bodyFatPercentage >= 0 && bodyFatPercentage <= 100 &&
                gender != null && (gender.equals("남성") || gender.equals("여성"));
    }

    // 프로필 요약 정보
    public String getProfileSummary() {
        StringBuilder summary = new StringBuilder();
        summary.append(String.format("%s (%s, %d세)\n", name, gender, age));
        summary.append(String.format("신체: %.1fcm, %.1fkg (BMI: %.1f)\n", height, weight, calculateBMI()));
        summary.append(String.format("체성분: 근육량 %.1fkg, 체지방률 %.1f%%\n", muscleMass, bodyFatPercentage));
        summary.append(String.format("목표: %s\n", fitnessGoal != null ? fitnessGoal.getDescription() : "설정 안됨"));
        summary.append(String.format("활동수준: %s", activityLevel != null ? activityLevel.getDescription() : "설정 안됨"));
        return summary.toString();
    }

    // Getters and Setters
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public double getHeight() {
        return height;
    }

    public void setHeight(double height) {
        this.height = height;
    }

    public double getWeight() {
        return weight;
    }

    public void setWeight(double weight) {
        this.weight = weight;
    }

    public double getMuscleMass() {
        return muscleMass;
    }

    public void setMuscleMass(double muscleMass) {
        this.muscleMass = muscleMass;
    }

    public double getBodyFatPercentage() {
        return bodyFatPercentage;
    }

    public void setBodyFatPercentage(double bodyFatPercentage) {
        this.bodyFatPercentage = bodyFatPercentage;
    }

    public LocalDate getLastUpdated() {
        return lastUpdated;
    }

    public void setLastUpdated(LocalDate lastUpdated) {
        this.lastUpdated = lastUpdated;
    }

    public FitnessGoal getFitnessGoal() {
        return fitnessGoal;
    }

    public void setFitnessGoal(FitnessGoal fitnessGoal) {
        this.fitnessGoal = fitnessGoal;
    }

    public ActivityLevel getActivityLevel() {
        return activityLevel;
    }

    public void setActivityLevel(ActivityLevel activityLevel) {
        this.activityLevel = activityLevel;
    }

    public Map<LocalDate, WeeklyRecord> getWeeklyRecords() {
        return weeklyRecords;
    }

    public void setWeeklyRecords(Map<LocalDate, WeeklyRecord> weeklyRecords) {
        this.weeklyRecords = weeklyRecords;
    }

    @Override
    public String toString() {
        return String.format("UserProfile{name='%s', age=%d, gender='%s', height=%.1f, weight=%.1f}",
                name, age, gender, height, weight);
    }
}
