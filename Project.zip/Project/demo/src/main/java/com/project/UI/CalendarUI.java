package com.project.UI;

import javax.swing.*;
import javax.swing.border.LineBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.time.LocalDate;
import java.time.YearMonth;
import java.time.format.DateTimeFormatter;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class CalendarUI extends JFrame {
    private mainUI parentUI;
    private LocalDate currentMonth;
    private LocalDate selectedDate;
    private JPanel calendarPanel;
    private JLabel monthLabel;
    private List<JButton> dayButtons;

    public CalendarUI(mainUI parent) {
        this.parentUI = parent;
        this.currentMonth = LocalDate.now().withDayOfMonth(1);
        this.selectedDate = LocalDate.now();
        this.dayButtons = new ArrayList<>();

        initializeUI();
        updateCalendar();
    }

    public void initializeUI() {
        setTitle("영양 추적 달력");
        setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
        setLayout(new BorderLayout());
        setResizable(false);

        // 상단 네비게이션 패널
        JPanel navigationPanel = createNavigationPanel();
        add(navigationPanel, BorderLayout.NORTH);

        // 달력 패널
        calendarPanel = new JPanel(new GridLayout(7, 7, 2, 2));
        calendarPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        add(calendarPanel, BorderLayout.CENTER);

        // 하단 정보 패널
        JPanel infoPanel = createInfoPanel();
        add(infoPanel, BorderLayout.SOUTH);

        setSize(700, 600);
        setLocationRelativeTo(parentUI);
    }

    public JPanel createNavigationPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        // 이전 달 버튼
        JButton prevButton = new JButton("◀");
        prevButton.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 16));
        prevButton.addActionListener(this::goToPreviousMonth);

        // 다음 달 버튼
        JButton nextButton = new JButton("▶");
        nextButton.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 16));
        nextButton.addActionListener(this::goToNextMonth);

        // 월/년 표시 라벨
        monthLabel = new JLabel();
        monthLabel.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 18));
        monthLabel.setHorizontalAlignment(SwingConstants.CENTER);

        // 오늘 버튼
        JButton todayButton = new JButton("오늘");
        todayButton.addActionListener(this::goToToday);

        panel.add(prevButton, BorderLayout.WEST);
        panel.add(monthLabel, BorderLayout.CENTER);
        panel.add(nextButton, BorderLayout.EAST);

        JPanel rightPanel = new JPanel(new FlowLayout());
        rightPanel.add(todayButton);
        panel.add(rightPanel, BorderLayout.SOUTH);

        return panel;
    }

    private void goToPreviousMonth(ActionEvent e) {
        currentMonth = currentMonth.minusMonths(1);
        updateCalendar();
    }

    private void goToNextMonth(ActionEvent e) {
        currentMonth = currentMonth.plusMonths(1);
        updateCalendar();
    }

    private void goToToday(ActionEvent e) {
        LocalDate today = LocalDate.now();
        currentMonth = today.withDayOfMonth(1);
        selectedDate = today;
        updateCalendar();
        parentUI.switchToDate(selectedDate);
    }

    public JPanel createInfoPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBorder(BorderFactory.createTitledBorder("범례"));

        JPanel legendPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));

        // 범례 항목들
        legendPanel.add(createLegendItem("오늘", Color.BLUE));
        legendPanel.add(createLegendItem("선택된 날짜", Color.GREEN));
        legendPanel.add(createLegendItem("목표 달성", new Color(144, 238, 144))); // 연한 초록
        legendPanel.add(createLegendItem("목표 미달성", new Color(255, 182, 193))); // 연한 빨강
        legendPanel.add(createLegendItem("데이터 없음", Color.WHITE));

        panel.add(legendPanel, BorderLayout.CENTER);

        // 사용법 안내
        JLabel instructionLabel = new JLabel(
                "<html><center>날짜를 클릭하여 해당 날짜로 이동<br/>색상으로 영양 목표 달성 여부 확인</center></html>");
        instructionLabel.setHorizontalAlignment(SwingConstants.CENTER);
        instructionLabel.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 12));
        panel.add(instructionLabel, BorderLayout.SOUTH);

        return panel;
    }

    public JPanel createLegendItem(String text, Color color) {
        JPanel item = new JPanel(new FlowLayout(FlowLayout.LEFT, 5, 0));

        JPanel colorBox = new JPanel();
        colorBox.setPreferredSize(new Dimension(15, 15));
        colorBox.setBackground(color);
        colorBox.setBorder(new LineBorder(Color.BLACK, 1));

        JLabel label = new JLabel(text);
        label.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 11));

        item.add(colorBox);
        item.add(label);

        return item;
    }

    public void updateCalendar() {
        calendarPanel.removeAll();
        dayButtons.clear();

        // 월/년 라벨 업데이트
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy년 MM월", Locale.KOREAN);
        monthLabel.setText(currentMonth.format(formatter));

        // 요일 헤더 추가
        String[] dayNames = { "일", "월", "화", "수", "목", "금", "토" };
        for (String dayName : dayNames) {
            JLabel dayLabel = new JLabel(dayName, SwingConstants.CENTER);
            dayLabel.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 12));
            dayLabel.setOpaque(true);
            dayLabel.setBackground(new Color(230, 230, 230));
            dayLabel.setBorder(new LineBorder(Color.GRAY, 1));
            calendarPanel.add(dayLabel);
        }

        // 달력 날짜 계산
        YearMonth yearMonth = YearMonth.of(currentMonth.getYear(), currentMonth.getMonth());
        LocalDate firstDay = yearMonth.atDay(1);
        int daysInMonth = yearMonth.lengthOfMonth();
        int startDayOfWeek = firstDay.getDayOfWeek().getValue() % 7; // 일요일=0

        // 이전 달의 빈 날짜들
        for (int i = 0; i < startDayOfWeek; i++) {
            JLabel emptyLabel = new JLabel();
            emptyLabel.setBorder(new LineBorder(Color.LIGHT_GRAY, 1));
            calendarPanel.add(emptyLabel);
        }

        // 현재 달의 날짜들
        for (int day = 1; day <= daysInMonth; day++) {
            LocalDate date = LocalDate.of(currentMonth.getYear(), currentMonth.getMonth(), day);
            JButton dayButton = createDayButton(date);
            dayButtons.add(dayButton);
            calendarPanel.add(dayButton);
        }

        // 다음 달의 빈 날짜들로 나머지 칸 채우기
        int totalCells = calendarPanel.getComponentCount();
        while (totalCells < 49) { // 7x7 = 49
            JLabel emptyLabel = new JLabel();
            emptyLabel.setBorder(new LineBorder(Color.LIGHT_GRAY, 1));
            calendarPanel.add(emptyLabel);
            totalCells++;
        }

        calendarPanel.revalidate();
        calendarPanel.repaint();
    }

    public JButton createDayButton(LocalDate date) {
        JButton button = new JButton(String.valueOf(date.getDayOfMonth()));
        button.setPreferredSize(new Dimension(80, 80));
        button.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 14));
        button.setBorder(new LineBorder(Color.GRAY, 1));
        button.setFocusPainted(false);

        // 날짜별 색상 및 텍스트 설정
        setupDayButtonAppearance(button, date);

        // 클릭 이벤트 - 메서드 참조 사용
        button.addActionListener(_ -> handleDateClick(date));

        // 마우스 오버 효과
        button.addMouseListener(new MouseAdapter() {
            Color originalColor = button.getBackground();

            @Override
            public void mouseEntered(MouseEvent e) {
                if (!date.equals(selectedDate) && !date.equals(LocalDate.now())) {
                    button.setBackground(new Color(220, 220, 220));
                }
            }

            @Override
            public void mouseExited(MouseEvent e) {
                if (!date.equals(selectedDate) && !date.equals(LocalDate.now())) {
                    button.setBackground(originalColor);
                }
            }
        });

        return button;
    }

    private void handleDateClick(LocalDate date) {
        selectedDate = date;
        parentUI.switchToDate(date);
        updateCalendar(); // 선택된 날짜 색상 업데이트

        // 달력 창을 숨기고 메인 UI로 포커스 이동
        setVisible(false);
        parentUI.toFront();
        parentUI.requestFocus();
    }

    public void setupDayButtonAppearance(JButton button, LocalDate date) {
        LocalDate today = LocalDate.now();

        // 기본 설정
        button.setBackground(Color.WHITE);
        button.setForeground(Color.BLACK);

        // 오늘 날짜 표시
        if (date.equals(today)) {
            button.setBackground(Color.BLUE);
            button.setForeground(Color.WHITE);
            button.setText(date.getDayOfMonth() + " (오늘)");
        }

        // 선택된 날짜 표시
        if (date.equals(selectedDate)) {
            button.setBackground(Color.GREEN);
            button.setForeground(Color.WHITE);
            if (!date.equals(today)) {
                button.setText(date.getDayOfMonth() + " (선택)");
            }
        }

        // 영양 데이터 기반 색상 설정
        mainUI.DailyNutritionData dailyData = mainUI.getDailyData(date);
        if (dailyData != null && !dailyData.foods.isEmpty()) {
            // 목표 달성 여부 확인
            boolean goalAchieved = checkGoalAchievement(dailyData);

            if (!date.equals(today) && !date.equals(selectedDate)) {
                if (goalAchieved) {
                    button.setBackground(new Color(144, 238, 144)); // 연한 초록색
                } else {
                    button.setBackground(new Color(255, 182, 193)); // 연한 빨간색
                }
            }

            // 데이터가 있는 날짜는 굵은 글씨
            button.setFont(new Font(Font.SANS_SERIF, Font.BOLD, 14));

            // 툴팁으로 간단한 정보 표시
            button.setToolTipText(createTooltipText(date, dailyData));
        } else {
            // 데이터가 없는 날짜
            button.setFont(new Font(Font.SANS_SERIF, Font.PLAIN, 14));
            button.setToolTipText("데이터 없음");
        }

        // 주말 색상 (데이터가 없고 선택되지 않은 경우)
        if (dailyData == null && !date.equals(today) && !date.equals(selectedDate)) {
            int dayOfWeek = date.getDayOfWeek().getValue();
            if (dayOfWeek == 6 || dayOfWeek == 7) { // 토요일, 일요일
                button.setForeground(new Color(100, 100, 100));
            }
        }
    }

    public boolean checkGoalAchievement(mainUI.DailyNutritionData dailyData) {
        if (dailyData == null || parentUI == null)
            return false;

        mainUI.NutritionGoals goals = parentUI.getGoals();
        mainUI.NutritionProgress progress = dailyData.progress;

        // 주요 영양소들이 목표의 80% 이상이면 달성으로 간주
        double calorieRatio = progress.calories / goals.calories;
        double proteinRatio = progress.protein / goals.protein;

        return calorieRatio >= 0.8 && proteinRatio >= 0.5; // 칼로리 80%, 단백질 50% 이상
    }

    public String createTooltipText(LocalDate date, mainUI.DailyNutritionData dailyData) {
        if (dailyData == null)
            return "데이터 없음";

        StringBuilder tooltip = new StringBuilder();
        tooltip.append("<html>");
        tooltip.append("<b>").append(date.format(DateTimeFormatter.ofPattern("M월 d일", Locale.KOREAN)))
                .append("</b><br>");
        tooltip.append("등록된 음식: ").append(dailyData.foods.size()).append("개<br>");
        tooltip.append("칼로리: ").append(String.format("%.0f", dailyData.progress.calories)).append(" kcal<br>");
        tooltip.append("단백질: ").append(String.format("%.1f", dailyData.progress.protein)).append(" g<br>");

        if (dailyData.foods.size() > 0) {
            tooltip.append("<br><b>주요 음식:</b><br>");
            for (int i = 0; i < Math.min(3, dailyData.foods.size()); i++) {
                mainUI.SelectedFood food = dailyData.foods.get(i);
                tooltip.append("• ").append(food.foodName).append(" (").append(String.format("%.0f", food.grams))
                        .append("g)<br>");
            }
            if (dailyData.foods.size() > 3) {
                tooltip.append("• ... 외 ").append(dailyData.foods.size() - 3).append("개");
            }
        }

        tooltip.append("</html>");
        return tooltip.toString();
    }

    // 외부에서 호출할 수 있는 날짜 업데이트 메서드
    public void updateSelectedDate(LocalDate date) {
        this.selectedDate = date;
        this.currentMonth = date.withDayOfMonth(1);
        updateCalendar();
    }

    // 특정 월로 이동
    public void goToMonth(int year, int month) {
        this.currentMonth = LocalDate.of(year, month, 1);
        updateCalendar();
    }

    @Override
    public void setVisible(boolean visible) {
        super.setVisible(visible);
        if (visible) {
            // 달력이 보여질 때 현재 선택된 날짜로 업데이트
            updateCalendar();
        }
    }
}
