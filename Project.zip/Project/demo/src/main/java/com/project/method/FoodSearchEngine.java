package com.project.method;

import java.util.*;
import java.util.stream.Collectors;

public class FoodSearchEngine {
    private ReadExcel readExcel;

    public FoodSearchEngine(ReadExcel readExcel) {
        this.readExcel = readExcel;
    }

    public List<Object> getExactNutrition(String foodName) {
        return readExcel.foodNutritionList.stream()
                .filter(pair -> pair.first.equalsIgnoreCase(foodName.trim()))
                .map(pair -> pair.second)
                .findFirst()
                .orElse(null);
    }

    public List<SearchResult> searchSimilarFoods(String searchTerm, int maxResults) {
        if (searchTerm == null || searchTerm.trim().isEmpty()) {
            return new ArrayList<>();
        }

        String normalizedSearchTerm = searchTerm.trim().toLowerCase();

        return readExcel.foodNutritionList.stream()
                .map(pair -> new SearchResult(
                        pair.first,
                        pair.second,
                        calculateSimilarity(normalizedSearchTerm, pair.first.toLowerCase())))
                .filter(result -> result.similarity > 0) // 유사도가 0보다 큰 것만
                .sorted((a, b) -> Double.compare(b.similarity, a.similarity)) // 유사도 내림차순
                .limit(maxResults)
                .collect(Collectors.toList());
    }

    public List<String> getAllFoodNames() {
        return readExcel.foodNutritionList.stream()
                .map(pair -> pair.first)
                .collect(Collectors.toList());
    }

    public List<SearchResult> searchByKeyword(String keyword, int maxResults) {
        if (keyword == null || keyword.trim().isEmpty()) {
            return new ArrayList<>();
        }

        String normalizedKeyword = keyword.trim().toLowerCase();

        return readExcel.foodNutritionList.stream()
                .filter(pair -> pair.first.toLowerCase().contains(normalizedKeyword))
                .map(pair -> new SearchResult(pair.first, pair.second, 1.0)) // 포함되면 유사도 1.0
                .limit(maxResults)
                .collect(Collectors.toList());
    }

    private double calculateSimilarity(String s1, String s2) {
        // 완전 일치
        if (s1.equals(s2)) {
            return 1.0;
        }

        // 포함 관계 확인 (높은 점수 부여)
        if (s2.contains(s1) || s1.contains(s2)) {
            return 0.8;
        }

        // Levenshtein Distance 계산
        int distance = levenshteinDistance(s1, s2);
        int maxLen = Math.max(s1.length(), s2.length());

        if (maxLen == 0)
            return 1.0;

        double similarity = 1.0 - (double) distance / maxLen;

        // 너무 낮은 유사도는 0으로 처리
        return similarity < 0.3 ? 0 : similarity;
    }

    private int levenshteinDistance(String s1, String s2) {
        int[][] dp = new int[s1.length() + 1][s2.length() + 1];

        for (int i = 0; i <= s1.length(); i++) {
            dp[i][0] = i;
        }

        for (int j = 0; j <= s2.length(); j++) {
            dp[0][j] = j;
        }

        for (int i = 1; i <= s1.length(); i++) {
            for (int j = 1; j <= s2.length(); j++) {
                if (s1.charAt(i - 1) == s2.charAt(j - 1)) {
                    dp[i][j] = dp[i - 1][j - 1];
                } else {
                    dp[i][j] = 1 + Math.min(Math.min(dp[i - 1][j], dp[i][j - 1]), dp[i - 1][j - 1]);
                }
            }
        }

        return dp[s1.length()][s2.length()];
    }

    public static class SearchResult {
        public final String foodName;
        public final List<Object> nutritionData;
        public final double similarity;

        public SearchResult(String foodName, List<Object> nutritionData, double similarity) {
            this.foodName = foodName;
            this.nutritionData = nutritionData;
            this.similarity = similarity;
        }

        @Override
        public String toString() {
            return String.format("%s", foodName);
        }
    }
}
