package com.project.method;

import com.project.UI.mainUI;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.fasterxml.jackson.core.type.TypeReference;

import java.io.*;
import java.time.LocalDate;
import java.util.HashMap;
import java.util.Map;
import java.util.List;
import java.util.ArrayList;

public class DataManager {
    private static final String DATA_DIR = "data";
    private static final String PROFILES_DIR = DATA_DIR + File.separator + "profiles";
    private static final String DAILY_DATA_FILE = DATA_DIR + File.separator + "daily_nutrition_data.json";
    private static final String PROFILES_LIST_FILE = DATA_DIR + File.separator + "profiles_list.json";
    private static final String LAST_PROFILE_FILE = DATA_DIR + File.separator + "last_profile.txt";

    private ObjectMapper objectMapper;

    public DataManager() {
        this.objectMapper = new ObjectMapper();

        // Jackson 모듈 및 설정
        this.objectMapper.registerModule(new JavaTimeModule());

        // Jackson 설정 - 오류 방지
        this.objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        this.objectMapper.configure(SerializationFeature.FAIL_ON_EMPTY_BEANS, false);
        this.objectMapper.configure(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS, false);

        createDataDirectories();
    }

    // 디렉토리 생성
    private void createDataDirectories() {
        try {
            File dataDir = new File(DATA_DIR);
            if (!dataDir.exists()) {
                boolean created = dataDir.mkdirs();
                if (created) {
                    System.out.println("데이터 디렉토리 생성: " + dataDir.getAbsolutePath());
                }
            }

            File profilesDir = new File(PROFILES_DIR);
            if (!profilesDir.exists()) {
                boolean created = profilesDir.mkdirs();
                if (created) {
                    System.out.println("프로필 디렉토리 생성: " + profilesDir.getAbsolutePath());
                }
            }
        } catch (Exception e) {
            System.err.println("디렉토리 생성 실패: " + e.getMessage());
        }
    }

    // 프로필 목록 관리
    public List<String> getProfileList() {
        try {
            File file = new File(PROFILES_LIST_FILE);
            if (file.exists() && file.length() > 0) {
                List<String> profiles = objectMapper.readValue(file, new TypeReference<List<String>>() {
                });
                System.out.println("프로필 목록 로드: " + profiles.size() + "개");
                return profiles != null ? profiles : new ArrayList<>();
            }
        } catch (Exception e) {
            System.err.println("프로필 목록 로드 실패: " + e.getMessage());
        }
        return new ArrayList<>();
    }

    private void saveProfileList(List<String> profileNames) {
        try {
            objectMapper.writeValue(new File(PROFILES_LIST_FILE), profileNames);
            System.out.println("프로필 목록 저장: " + profileNames.size() + "개");
        } catch (Exception e) {
            System.err.println("프로필 목록 저장 실패: " + e.getMessage());
        }
    }

    // 마지막 사용 프로필 관리
    public void saveLastUsedProfile(String profileName) {
        try (FileWriter writer = new FileWriter(LAST_PROFILE_FILE, false)) {
            writer.write(profileName);
            System.out.println("마지막 사용 프로필 저장: " + profileName);
        } catch (Exception e) {
            System.err.println("마지막 프로필 저장 실패: " + e.getMessage());
        }
    }

    public String getLastUsedProfile() {
        try {
            File file = new File(LAST_PROFILE_FILE);
            if (file.exists() && file.length() > 0) {
                try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
                    String profileName = reader.readLine();
                    if (profileName != null && !profileName.trim().isEmpty()) {
                        System.out.println("마지막 사용 프로필 로드: " + profileName);
                        return profileName.trim();
                    }
                }
            }
        } catch (Exception e) {
            System.err.println("마지막 프로필 로드 실패: " + e.getMessage());
        }
        return null;
    }

    // 프로필별 사용자 프로필 관리
    public void saveUserProfile(UserProfile userProfile, String profileName) {
        try {
            if (userProfile == null || profileName == null || profileName.trim().isEmpty()) {
                System.err.println("유효하지 않은 프로필 데이터");
                return;
            }

            String fileName = PROFILES_DIR + File.separator + profileName + "_profile.json";
            File file = new File(fileName);

            // 부모 디렉토리 확인
            file.getParentFile().mkdirs();

            objectMapper.writeValue(file, userProfile);

            // 프로필 목록에 추가
            List<String> profiles = getProfileList();
            if (!profiles.contains(profileName)) {
                profiles.add(profileName);
                saveProfileList(profiles);
            }

            System.out.println("사용자 프로필 저장 완료: " + profileName);
        } catch (Exception e) {
            System.err.println("사용자 프로필 저장 실패 (" + profileName + "): " + e.getMessage());
            e.printStackTrace();
        }
    }

    public UserProfile loadUserProfile(String profileName) {
        try {
            if (profileName == null || profileName.trim().isEmpty()) {
                System.err.println("유효하지 않은 프로필명");
                return null;
            }

            String fileName = PROFILES_DIR + File.separator + profileName + "_profile.json";
            File file = new File(fileName);

            if (file.exists() && file.length() > 0) {
                UserProfile profile = objectMapper.readValue(file, UserProfile.class);
                System.out.println("사용자 프로필 로드 완료: " + profileName);
                return profile;
            } else {
                System.out.println("프로필 파일이 존재하지 않음: " + fileName);
            }
        } catch (Exception e) {
            System.err.println("사용자 프로필 로드 실패 (" + profileName + "): " + e.getMessage());
            e.printStackTrace();
        }
        return null;
    }

    // 프로필별 영양 목표 관리
    public void saveNutritionGoals(mainUI.NutritionGoals goals, String profileName) {
        try {
            if (goals == null || profileName == null || profileName.trim().isEmpty()) {
                System.err.println("유효하지 않은 영양 목표 데이터");
                return;
            }

            String fileName = PROFILES_DIR + File.separator + profileName + "_goals.json";
            File file = new File(fileName);

            // 부모 디렉토리 확인
            file.getParentFile().mkdirs();

            objectMapper.writeValue(file, goals);
            System.out.println("영양 목표 저장 완료: " + profileName);
        } catch (Exception e) {
            System.err.println("영양 목표 저장 실패 (" + profileName + "): " + e.getMessage());
            e.printStackTrace();
        }
    }

    public mainUI.NutritionGoals loadNutritionGoals(String profileName) {
        try {
            if (profileName == null || profileName.trim().isEmpty()) {
                System.err.println("유효하지 않은 프로필명");
                return null;
            }

            String fileName = PROFILES_DIR + File.separator + profileName + "_goals.json";
            File file = new File(fileName);

            if (file.exists() && file.length() > 0) {
                mainUI.NutritionGoals goals = objectMapper.readValue(file, mainUI.NutritionGoals.class);
                System.out.println("영양 목표 로드 완료: " + profileName);
                return goals;
            } else {
                System.out.println("영양 목표 파일이 존재하지 않음: " + fileName);
            }
        } catch (Exception e) {
            System.err.println("영양 목표 로드 실패 (" + profileName + "): " + e.getMessage());
            e.printStackTrace();
        }
        return null;
    }

    // 프로필별 일일 데이터 관리
    public void saveDailyData(Map<LocalDate, mainUI.DailyNutritionData> dailyDataMap, String profileName) {
        try {
            if (dailyDataMap == null || profileName == null || profileName.trim().isEmpty()) {
                System.err.println("유효하지 않은 일일 데이터");
                return;
            }

            String fileName = PROFILES_DIR + File.separator + profileName + "_daily_data.json";
            File file = new File(fileName);

            // 부모 디렉토리 확인
            file.getParentFile().mkdirs();

            objectMapper.writeValue(file, dailyDataMap);
            System.out.println("일일 데이터 저장 완료: " + profileName + " (" + dailyDataMap.size() + "개 날짜)");
        } catch (Exception e) {
            System.err.println("일일 데이터 저장 실패 (" + profileName + "): " + e.getMessage());
            e.printStackTrace();
        }
    }

    public Map<LocalDate, mainUI.DailyNutritionData> loadDailyData(String profileName) {
        try {
            if (profileName == null || profileName.trim().isEmpty()) {
                System.err.println("유효하지 않은 프로필명");
                return new HashMap<>();
            }

            String fileName = PROFILES_DIR + File.separator + profileName + "_daily_data.json";
            File file = new File(fileName);

            if (file.exists() && file.length() > 0) {
                TypeReference<Map<LocalDate, mainUI.DailyNutritionData>> typeRef = new TypeReference<Map<LocalDate, mainUI.DailyNutritionData>>() {
                };

                Map<LocalDate, mainUI.DailyNutritionData> data = objectMapper.readValue(file, typeRef);
                System.out.println("일일 데이터 로드 완료: " + profileName + " (" + data.size() + "개 날짜)");
                return data != null ? data : new HashMap<>();
            } else {
                System.out.println("일일 데이터 파일이 존재하지 않음: " + fileName);
            }
        } catch (Exception e) {
            System.err.println("일일 데이터 로드 실패 (" + profileName + "): " + e.getMessage());
            e.printStackTrace();
        }
        return new HashMap<>();
    }

    // 프로필 삭제
    public boolean deleteProfile(String profileName) {
        try {
            if (profileName == null || profileName.trim().isEmpty()) {
                System.err.println("유효하지 않은 프로필명");
                return false;
            }

            // 프로필 관련 파일들 삭제
            String profileFile = PROFILES_DIR + File.separator + profileName + "_profile.json";
            String goalsFile = PROFILES_DIR + File.separator + profileName + "_goals.json";
            String dailyDataFile = PROFILES_DIR + File.separator + profileName + "_daily_data.json";

            boolean success = true;

            File pFile = new File(profileFile);
            if (pFile.exists()) {
                success &= pFile.delete();
            }

            File gFile = new File(goalsFile);
            if (gFile.exists()) {
                success &= gFile.delete();
            }

            File dFile = new File(dailyDataFile);
            if (dFile.exists()) {
                success &= dFile.delete();
            }

            // 프로필 목록에서 제거
            List<String> profiles = getProfileList();
            if (profiles.remove(profileName)) {
                saveProfileList(profiles);
            }

            // 마지막 사용 프로필이었다면 제거
            String lastUsed = getLastUsedProfile();
            if (profileName.equals(lastUsed)) {
                try {
                    new File(LAST_PROFILE_FILE).delete();
                } catch (Exception e) {
                    System.err.println("마지막 프로필 파일 삭제 실패: " + e.getMessage());
                }
            }

            System.out.println("프로필 삭제 완료: " + profileName);
            return success;

        } catch (Exception e) {
            System.err.println("프로필 삭제 실패 (" + profileName + "): " + e.getMessage());
            return false;
        }
    }

    // 백업 기능
    public void backupProfile(String profileName) {
        try {
            if (profileName == null || profileName.trim().isEmpty()) {
                System.err.println("유효하지 않은 프로필명");
                return;
            }

            String timestamp = LocalDate.now().toString().replace("-", "");
            String backupDir = DATA_DIR + File.separator + "backup_" + profileName + "_" + timestamp;

            File backupDirectory = new File(backupDir);
            if (!backupDirectory.exists()) {
                backupDirectory.mkdirs();
            }

            // 프로필 파일들 백업
            String profileFile = PROFILES_DIR + File.separator + profileName + "_profile.json";
            String goalsFile = PROFILES_DIR + File.separator + profileName + "_goals.json";
            String dailyDataFile = PROFILES_DIR + File.separator + profileName + "_daily_data.json";

            copyFileIfExists(profileFile, backupDir + File.separator + "profile.json");
            copyFileIfExists(goalsFile, backupDir + File.separator + "goals.json");
            copyFileIfExists(dailyDataFile, backupDir + File.separator + "daily_data.json");

            System.out.println("프로필 백업 완료: " + backupDir);

        } catch (Exception e) {
            System.err.println("프로필 백업 실패 (" + profileName + "): " + e.getMessage());
        }
    }

    private void copyFileIfExists(String sourcePath, String destPath) {
        try {
            File sourceFile = new File(sourcePath);
            if (sourceFile.exists()) {
                try (FileInputStream fis = new FileInputStream(sourceFile);
                        FileOutputStream fos = new FileOutputStream(destPath)) {

                    byte[] buffer = new byte[1024];
                    int length;
                    while ((length = fis.read(buffer)) > 0) {
                        fos.write(buffer, 0, length);
                    }
                }
                System.out.println("파일 복사 완료: " + sourcePath + " -> " + destPath);
            }
        } catch (Exception e) {
            System.err.println("파일 복사 실패: " + sourcePath + " -> " + e.getMessage());
        }
    }

    // 하위 호환성을 위한 기존 메서드들
    public void saveDailyData(Map<LocalDate, mainUI.DailyNutritionData> dailyDataMap) {
        try {
            if (dailyDataMap != null) {
                objectMapper.writeValue(new File(DAILY_DATA_FILE), dailyDataMap);
                System.out.println("일일 데이터 저장 (기본): " + dailyDataMap.size() + "개 날짜");
            }
        } catch (Exception e) {
            System.err.println("일일 데이터 저장 실패 (기본): " + e.getMessage());
        }
    }

    public Map<LocalDate, mainUI.DailyNutritionData> loadDailyData() {
        try {
            File file = new File(DAILY_DATA_FILE);
            if (file.exists() && file.length() > 0) {
                TypeReference<Map<LocalDate, mainUI.DailyNutritionData>> typeRef = new TypeReference<Map<LocalDate, mainUI.DailyNutritionData>>() {
                };

                Map<LocalDate, mainUI.DailyNutritionData> data = objectMapper.readValue(file, typeRef);
                System.out.println("일일 데이터 로드 (기본): " + data.size() + "개 날짜");
                return data != null ? data : new HashMap<>();
            }
        } catch (Exception e) {
            System.err.println("일일 데이터 로드 실패 (기본): " + e.getMessage());
        }
        return new HashMap<>();
    }

    // 전체 백업 (모든 프로필)
    public void backupAllData() {
        try {
            String timestamp = LocalDate.now().toString().replace("-", "");
            String backupDir = DATA_DIR + File.separator + "backup_all_" + timestamp;

            File backupDirectory = new File(backupDir);
            if (!backupDirectory.exists()) {
                backupDirectory.mkdirs();
            }

            // 전체 데이터 디렉토리 복사
            copyDirectory(new File(DATA_DIR), backupDirectory);

            System.out.println("전체 데이터 백업 완료: " + backupDir);

        } catch (Exception e) {
            System.err.println("전체 백업 실패: " + e.getMessage());
        }
    }

    private void copyDirectory(File sourceDir, File destDir) throws IOException {
        if (!destDir.exists()) {
            destDir.mkdirs();
        }

        File[] files = sourceDir.listFiles();
        if (files != null) {
            for (File file : files) {
                File destFile = new File(destDir, file.getName());
                if (file.isDirectory()) {
                    copyDirectory(file, destFile);
                } else {
                    try (FileInputStream fis = new FileInputStream(file);
                            FileOutputStream fos = new FileOutputStream(destFile)) {

                        byte[] buffer = new byte[1024];
                        int length;
                        while ((length = fis.read(buffer)) > 0) {
                            fos.write(buffer, 0, length);
                        }
                    }
                }
            }
        }
    }

    // 데이터 무결성 검사
    public boolean validateProfileData(String profileName) {
        try {
            if (profileName == null || profileName.trim().isEmpty()) {
                return false;
            }

            String profileFile = PROFILES_DIR + File.separator + profileName + "_profile.json";
            String goalsFile = PROFILES_DIR + File.separator + profileName + "_goals.json";
            String dailyDataFile = PROFILES_DIR + File.separator + profileName + "_daily_data.json";

            // 파일 존재 확인
            File pFile = new File(profileFile);
            File gFile = new File(goalsFile);
            File dFile = new File(dailyDataFile);

            boolean profileExists = pFile.exists() && pFile.length() > 0;
            boolean goalsExists = gFile.exists() && gFile.length() > 0;
            boolean dailyDataExists = dFile.exists() && dFile.length() > 0;

            System.out.println("프로필 검증 (" + profileName + "): " +
                    "프로필=" + profileExists + ", 목표=" + goalsExists + ", 일일데이터=" + dailyDataExists);

            return profileExists; // 최소한 프로필 파일은 있어야 함

        } catch (Exception e) {
            System.err.println("프로필 검증 실패 (" + profileName + "): " + e.getMessage());
            return false;
        }
    }

    // 설정 정보 출력
    public void printDataManagerInfo() {
        System.out.println("=== DataManager 정보 ===");
        System.out.println("데이터 디렉토리: " + new File(DATA_DIR).getAbsolutePath());
        System.out.println("프로필 디렉토리: " + new File(PROFILES_DIR).getAbsolutePath());
        System.out.println("등록된 프로필 수: " + getProfileList().size());
        System.out.println("마지막 사용 프로필: " + getLastUsedProfile());
        System.out.println("Jackson 설정: LocalDate 지원, 알 수 없는 속성 무시");
    }
}
